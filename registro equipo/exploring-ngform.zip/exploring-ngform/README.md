# Exploring ngForm

A Pen created on CodePen.io. Original URL: [https://codepen.io/rlo206/pen/KdEwEg](https://codepen.io/rlo206/pen/KdEwEg).

Angular forms done the angular way.