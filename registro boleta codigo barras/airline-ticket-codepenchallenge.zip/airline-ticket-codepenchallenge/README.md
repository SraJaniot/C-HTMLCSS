# Airline Ticket #CodePenChallenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/jesusrmz/pen/yLbGJWb](https://codepen.io/jesusrmz/pen/yLbGJWb).

CodePen Challenge for the second week of August