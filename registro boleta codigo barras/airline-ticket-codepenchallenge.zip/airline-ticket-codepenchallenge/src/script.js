// Based in a Dribbble from Barna Erdei
// Link: https://dribbble.com/shots/11399236-Boarding-Pass
