# Character Showcase Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/pleasedonotdisturb/pen/poqrZLZ](https://codepen.io/pleasedonotdisturb/pen/poqrZLZ).

I couldn’t use copyrighted anime images. Instead, I generated the images using stable diffusion XL (for ethical reasons, no artist is used in the prompts :))

Inspired from [this tutorial by *Online Tutorials*](https://youtu.be/-9vp6PyBZdE)

[View Source Code](https://github.com/pleasedonotdisturb/character-showcase-gallery)